import java.util.Scanner;

public class Main {
   public static void main (String [] args) {
      Scanner scnr = new Scanner(System.in);//create a Scanner to read from System.in
      int firstNum = 0; //number person enters
      int finalNum = 0; //number I give back
      
      System.out.println("Please enter a number:");//prompt the user for input
      
      firstNum = scnr.nextInt();//get an integer from the user with your Scanner
      System.out.println(firstNum);
      
      finalNum = firstNum + 1;//add 1 to the variable holding the input
      System.out.println(finalNum);//output the variable
      
      return;
   }
}